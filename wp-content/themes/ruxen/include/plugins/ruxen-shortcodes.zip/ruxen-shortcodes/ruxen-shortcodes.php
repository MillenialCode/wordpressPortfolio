<?php
/**
* Plugin Name: Ruxen Shortcodes
* Plugin URI: http://themeforest.net/user/gloriatheme
* Description: Ruxen - blog & magazine theme shortcode plugin
* Version: 1.0
* Author: Gloria Theme
* Author URI: http://gloriatheme.com/
*/

/*------------- SHORTCODE START -------------*/
/*------------- DROPCAP SHORTCODE START -------------*/
function dropcap_shortcode( $dropcap_atts , $dropcap_content = null ) {
	echo '<span class="dropcap">'. $dropcap_content .'</span>';
}
add_shortcode( 'dropcap', 'dropcap_shortcode' );
/*------------- DROPCAP SHORTCODE END -------------*/
/*------------- BUTTON SHORTCODE START -------------*/
function ruxen_shortcode_button( $button_atts , $button_content = null ) {
	extract( shortcode_atts(
		array(
			'background' => '#000000',
			'color' => '#FFF',
			'style' => '1',
			'link' => '#',
		), $button_atts )
	);
	$ruxen_button_background = esc_attr( $background );
	if ( !empty( $ruxen_button_background ) )
	{
		$ruxen_button_background = $ruxen_button_background;
	}
	$ruxen_button_color = strip_tags( esc_attr( $color ) );
	if ( !empty( $ruxen_button_color ) )
	{
		$ruxen_button_color = $ruxen_button_color;
	}
	$ruxen_button_style = strip_tags( esc_attr( $style ) );
	if ( empty( $ruxen_button_style ) )
	{
		$ruxen_button_style = "1";
	}
	$ruxen_button_link = strip_tags( esc_attr( $link ) );
	$button_content = strip_tags( esc_attr( $button_content ) );
	if ( $ruxen_button_style == "1" )
	{
		return '<div class="ruxen_button ruxen_button_style1" style="border-color:' . $ruxen_button_background . ';"><a href="' . $ruxen_button_link .'" style="color:' . $ruxen_button_color . ';border-color:' . $ruxen_button_background . ';">' . $button_content . '</a></div>';
	}
	else if ( $ruxen_button_style == "2" )
	{
		return '<div class="ruxen_button ruxen_button_style2"  style="border-color:' . $ruxen_button_background . ';"><a href="' . $ruxen_button_link .'" style="color:' . $ruxen_button_color . ';border-color:' . $ruxen_button_background . ';">' . $button_content . '</a></div>';
	}	
	else if ( $ruxen_button_style == "3" )
	{
		return '<div class="ruxen_button ruxen_button_style3"  style="background-color:' . $ruxen_button_background . ';border-color:' . $ruxen_button_background . ';"><a href="' . $ruxen_button_link .'" style="color:' . $ruxen_button_color . ';border-color:' . $ruxen_button_background . ';">' . $button_content . '</a></div>';
	}
}
add_shortcode( 'ruxen_button', 'ruxen_shortcode_button' );
/*------------- BUTTON SHORTCODE END -------------*/
/*------------- COLUMN SHORTCODE START -------------*/
function ruxen_shortcode_column( $column_atts , $column_content = null ) {
	extract( shortcode_atts(
		array(
			'size' => '1',
		), $column_atts )
	);	
	$size = strip_tags( esc_attr( $size ) );
	if ( $size == "1" )
	{
		return '<div class="col-sm-1 col-xs-12">' . do_shortcode( $column_content ) . '</div>';
	}
	elseif ( $size == "2" )
	{
		return '<div class="col-sm-2 col-xs-12">' . do_shortcode( $column_content ) . '</div>';
	}
	elseif ( $size == "3" )
	{
		return '<div class="col-sm-3 col-xs-12">' . do_shortcode( $column_content ) . '</div>';
	}
	elseif ( $size == "4" )
	{
		return '<div class="col-sm-4 col-xs-12">' . do_shortcode( $column_content ) . '</div>';
	}
	elseif ( $size == "5" )
	{
		return '<div class="col-sm-5 col-xs-12">' . do_shortcode( $column_content ) . '</div>';
	}
	elseif ( $size == "6" )
	{
		return '<div class="col-sm-6 col-xs-12">' . do_shortcode( $column_content ) . '</div>';
	}
	elseif ( $size == "7" )
	{
		return '<div class="col-sm-7 col-xs-12">' . do_shortcode( $column_content ) . '</div>';
	}
	elseif ( $size == "8" )
	{
		return '<div class="col-sm-8 col-xs-12">' . do_shortcode( $column_content ) . '</div>';
	}
	elseif ( $size == "9" )
	{
		return '<div class="col-sm-9 col-xs-12">' . do_shortcode( $column_content ) . '</div>';
	}
	elseif ( $size == "10" )
	{
		return '<div class="col-sm-10 col-xs-12">' . do_shortcode( $column_content ) . '</div>';
	}
	
	elseif ( $size == "11" )
	{
		return '<div class="col-sm-11 col-xs-12">' . do_shortcode( $column_content ) . '</div>';
	}
	elseif ( $size == "12" )
	{
		return '<div class="col-sm-12 col-xs-12">' . do_shortcode( $column_content ) . '</div>';
	}
}
add_shortcode( 'columns', 'ruxen_shortcode_column' );
/*------------- COLUMN SHORTCODE END -------------*/
/*------------- ROW SHORTCODE START -------------*/
function ruxen_shortcode_row( $row_atts , $row_content = null ) {
	extract( shortcode_atts(
		array(
			'class' => 'clearfix',
		), $row_atts )
	);
	$class = strip_tags( esc_attr( $class ) );
	return '<div class="row ' . $class . '">' . do_shortcode( $row_content ) . '</div>';	
}
add_shortcode( 'rows', 'ruxen_shortcode_row' );
/*------------- ROW SHORTCODE END -------------*/
/*------------- TABS SHORTCODE START -------------*/
function ruxen_shortcode_bootstraptabs_wp_init() {
	global $bootstraptabs_count, $bootstraptabs_tab_count, $bootstraptabs_content;
			$bootstraptabs_count = 0;
			$bootstraptabs_tab_count = 0;
			$bootstraptabs_content = array();
}
add_action( 'wp', 'ruxen_shortcode_bootstraptabs_wp_init' );
function ruxen_shortcode_bootstraptabs_tab_shortcode($atts,$content) {
	extract(shortcode_atts(array(
		'name' => 'Tab Name',
		'icon' => '',
		'link' => '',
		'active' => '',
	), $atts));
	global $bootstraptabs_content,$bootstraptabs_tab_count,$bootstraptabs_count;
	$bootstraptabs_content[$bootstraptabs_tab_count]['name'] = strip_tags( esc_attr( $name ) );
	$bootstraptabs_content[$bootstraptabs_tab_count]['icon'] = strip_tags( esc_attr( $icon ) );
	$bootstraptabs_content[$bootstraptabs_tab_count]['link'] = strip_tags( esc_attr( $link ) );
	$bootstraptabs_content[$bootstraptabs_tab_count]['active'] = strip_tags( esc_attr( $active ) );  
	$bootstraptabs_content[$bootstraptabs_tab_count]['content'] = do_shortcode( $content );
	$bootstraptabs_tab_count = $bootstraptabs_tab_count + 1;
}
add_shortcode('tab', 'ruxen_shortcode_bootstraptabs_tab_shortcode');
function ruxen_shortcode_bootstraptabs_end_shortcode($atts) {
global $bootstraptabs_content, $bootstraptabs_tab_count, $bootstraptabs_count;
		if( $bootstraptabs_tab_count != 0 and isset( $bootstraptabs_tab_count ) ) {
		$tab_content = '<ul id="tabs" class="nav nav-tabs" data-tabs="tabs">'; 
			for( $i = 0; $i < $bootstraptabs_tab_count; $i++ ) {
				$icon_tab = '';
				if ( !empty( $bootstraptabs_content[$i]['icon'] ) ):
					$icon_tab = '<i class="fa fa-' . $bootstraptabs_content[$i]['icon'] . '"></i>';
				endif;
				$tab_content = $tab_content . '<li class="tabs ' . $bootstraptabs_content[$i]['active'] . '"><a data-toggle="tab" href="#' . $bootstraptabs_content[$i]['link'] . '">' . $icon_tab . $bootstraptabs_content[$i]['name'] . '</a></li>';
			}
			$tab_content = $tab_content.'</ul><div id="my-tab-content" class="tab-content">';
			$tab_html = '';
			for( $i = 0; $i < $bootstraptabs_tab_count; $i++ ) {
				$link_html = $bootstraptabs_content[$i]['link'];
					$tab_html.='<div id="' . $bootstraptabs_content[$i]['link'] . '" class="tab-pane ' . $bootstraptabs_content[$i]['active'] . '"><p>' . $bootstraptabs_content[$i]['content'] . '</p></div>';
			}
			$tab_content = $tab_content . $tab_html;
		}		
		$tab_content = $tab_content . '</div>';
		return $tab_content;
}
add_shortcode('end_tabs', 'ruxen_shortcode_bootstraptabs_end_shortcode');
/*------------- TABS SHORTCODE END -------------*/
/*------------- ICON SHORTCODE START -------------*/
function ruxen_shortcode_font_icons( $font_icons_atts ) {
	extract( shortcode_atts(
		array(
			'icon' => '',			'color' => '',
			'size' => ''
		), $font_icons_atts )
	);
	$icon = strip_tags( esc_attr( $icon ) );
	$size = strip_tags( esc_attr( $size ) );
	$color = strip_tags( esc_attr( $color ) );
	$color_icon = "";
	if ( !empty( $color ) )	{		$color_icon = $color;	}
	return '<i class="icon-shortcode fa fa-' . $icon . '" style="font-size:' . $size . 'px; color:' . $color_icon . ';"></i>';
}
add_shortcode( 'ruxen_icon', 'ruxen_shortcode_font_icons' );
/*------------- ICON SHORTCODE END -------------*/
/*------------- ACCORDION SHORTCODE START -------------*/
add_shortcode("collapse_group", "ruxen_shortcode_collapse_group");
function ruxen_shortcode_collapse_group( $atts, $content = null ) {  
	extract(shortcode_atts(array(  
		'id' => '',
		'class' => ''
	), $atts));  
	$output  = '<div class="panel-group ' . $class . '" id="accordion" role="tablist" aria-multiselectable="true"';
	if(!empty($id))
		$output .= 'id="' . $id . '"';
	$output .='>'.do_shortcode($content).'</div>';
	return $output;  
}  
function ruxen_shortcode_collapse($collapse_atts, $collapse_content = null) {  
    extract(shortcode_atts( array(  
		'id' => '',
		'icon' => '',
		'title' => '',
		'open'=>'n'
    ), $collapse_atts));  
	$id = strip_tags( esc_attr( $id ) );
	$open = strip_tags( esc_attr( $open ) );
	$title = strip_tags( esc_attr( $title ) );
    if( empty( $id ) ) :
		$id = 'accordian_item_' . rand( 100, 999 );
	endif;
	$icons = strip_tags( esc_attr( $icon ) );
	if ( !empty( $icons ) ):
		$icon_collapse = '<i class="fa fa-' . $icons . '"></i>';
	else:
		$icon_collapse = '';
	endif;
    $output = '<div class="panel panel-default">
        <div class="panel-heading" role="tab" id="heading' . $id . '">
			<h4 class="panel-title">
				<a data-toggle="collapse" data-parent="#accordion" class="accordion-toggle" aria-controls="collapse' . $id . '" href="#collapse' . $id . '">' . $icon_collapse . $title . '</a>
			</h4>
	   </div>
			<div id="collapse' . $id . '" role="tabpanel" aria-labelledby="heading' . $id . '" class="panel-collapse collapse ' .(  $open == 'y' ? 'in' : '' ) . '">
				<div class="panel-body">' . do_shortcode( $collapse_content ) . '</div>
			</div>
        </div>';		
    return $output;	
} 
add_shortcode("collapse", "ruxen_shortcode_collapse");
/*------------- ACCORDION SHORTCODE END -------------*/
/*------------- ALERTS SHORTCODE START -------------*/
function ruxen_alerts( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'type' => 'info',
		'close' => 'false',
	), $atts ) );	
	$type = strip_tags( esc_attr( $type ) );
	$close = strip_tags( esc_attr( $close ) );
	$out = '<div class="alert alert-' . $type . '">';	
	if($close == 'true') {
		$out .= '<button type="button" class="close" data-dismiss="alert">&times;</button>';
	}
	$out .= do_shortcode( $content );
	$out .= '</div>';
	return $out;
}add_shortcode('alert', 'ruxen_alerts');
/*------------- ALERTS SHORTCODE END -------------*/
/*------------- PANEL START -------------*/
function panel_shortcode( $atts , $content = null ) {
	return '<div class="panel panel-default">
		<div class="panel-body">' . do_shortcode( $content ) . '</div>
	</div>';
}
add_shortcode( 'panel', 'panel_shortcode' );
/*------------- PANEL END -------------*/
/*------------- PROGRESS BAR START -------------*/
function progressbar_shortcode( $atts , $content = null ) {

	// Attributes
	extract( shortcode_atts(
		array(
			'now' => '50',
			'min' => '0',
			'max' => '100',
			'type' => 'success',
		), $atts )
	);
	
	
		return '<div class="progress">
			<div class="progress-bar progress-bar-' . strip_tags( esc_attr( $type ) ) . ' progress-bar-striped" role="progressbar" aria-valuenow="' . strip_tags( esc_attr( $now ) ) . '" aria-valuemin="' . strip_tags( esc_attr( $min ) ) . '" aria-valuemax="' . strip_tags( esc_attr( $max ) ) . '" style="width: ' . strip_tags( esc_attr( $now ) ) . '%">
				<span class="sr-only">' . strip_tags( esc_attr( $now ) ) . '</span>
			</div>
		</div>';
}
add_shortcode( 'progressbar', 'progressbar_shortcode' );
/*------------- PROGRESS BAR END -------------*/
/*------------- LABELS START -------------*/
function label_shortcode( $atts , $content = null ) {

	// Attributes
	extract( shortcode_atts(
		array(
			'type' => 'default',
		), $atts )
	);	
	return '<span class="label label-' . strip_tags( esc_attr( $type ) ) . '">' . do_shortcode( $content ) . '</span>';
}
add_shortcode( 'label', 'label_shortcode' );
/*------------- LABELS END -------------*/
/*------------- TESTIMONIAL START -------------*/
function testimonial_shortcode( $atts , $testimonials_content = null ) {
	return '<div class="testimonial-content">' . do_shortcode( $testimonials_content ). '</div>';
}
add_shortcode( 'testimonials', 'testimonial_shortcode' );
/*------------- TESTIMONIAL END -------------*/