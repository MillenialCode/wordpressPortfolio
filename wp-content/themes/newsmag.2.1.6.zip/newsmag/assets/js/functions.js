jQuery(document).ready(function ($) {
	MachoThemes.init($);
});
